#!/usr/bin/env python3
"""Run one step of a recorded run-through (RUN_* settings in run_env.py; default: the Mac mini) and record it as an asciinema v2 cast (real output, real timing).

    rec.py <cast name> "<title shown in the recording>" <command to run on the mac>
Appends to recordings/.../terminal/<cast name>.cast so a whole chapter can be several steps.
"""
import json, os, subprocess, sys, time
from pathlib import Path
sys.path.insert(0, str(Path(__file__).parent))
from run_env import HOST, PROMPT, SHELL, REC
out = REC / "terminal" / (sys.argv[1] + ".cast")
out.parent.mkdir(parents=True, exist_ok=True)
title, command = sys.argv[2], sys.argv[3]
new = not out.exists()
start = time.time()
with out.open("a") as cast:
    if new:
        cast.write(json.dumps({"version": 2, "width": 120, "height": 34, "timestamp": int(start), "title": title,
                               "env": {"SHELL": SHELL, "TERM": "xterm-256color"}}) + "\n")
        offset = 0.0
    else:
        lines = out.read_text().splitlines()
        offset = json.loads(lines[-1])[0] + 1.0 if len(lines) > 1 else 0.0
    def emit(text):
        cast.write(json.dumps([round(offset + time.time() - start, 3), "o", text]) + "\n"); cast.flush()
    emit(f"{PROMPT}\x1b[1m# {title}\x1b[0m\r\n")
    shown = command if len(command) < 400 else command[:400] + " …"
    emit(f"{PROMPT}{shown}\r\n")
    proc = subprocess.Popen(["ssh", "-o", "BatchMode=yes", HOST, "export PATH=$HOME/.local/bin:$PATH; " + command],
                            stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True, bufsize=1)
    for line in proc.stdout:
        sys.stdout.write(line); sys.stdout.flush()
        emit(line.rstrip("\n") + "\r\n")
    code = proc.wait()
    emit(f"\x1b[2m(exit {code}, {time.time() - start:.1f} s)\x1b[0m\r\n")
sys.exit(code)
