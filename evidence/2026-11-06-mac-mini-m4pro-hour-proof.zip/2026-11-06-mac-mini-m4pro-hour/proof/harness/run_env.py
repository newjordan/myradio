"""Which machine a recorded run targets. Defaults are the Mac mini run (2026-11-06); set RUN_* to point at another machine."""
import os
from pathlib import Path

HOST = os.environ.get("RUN_HOST", "mini")                                  # ssh alias of the machine under test
PROMPT = os.environ.get("RUN_PROMPT", "\x1b[1;32mfrosty40@mac-mini\x1b[0m \x1b[1;34m~\x1b[0m % ")
SHELL = os.environ.get("RUN_SHELL", "/bin/zsh")
REC = Path(os.environ.get("RUN_REC", str(Path.home() / "myradio-promo/recordings/2026-11-06-mac-mini")))
DATA = os.environ.get("RUN_DATA", "~/.myradio-skatepark")                 # myradio data dir on that machine
TRIAL = os.environ.get("RUN_TRIAL", "~/myradio-trial")                    # myradio checkout on that machine
REMOTE_PORT = int(os.environ.get("RUN_REMOTE_PORT", "8765"))
LOCAL_PORT = int(os.environ.get("RUN_LOCAL_PORT", "8765"))                # SSH tunnel end on this machine
SONGS = Path(os.environ.get("RUN_SONGS", str(Path.home() / "myradio-promo/skatepark-songs.json")))
STATION = os.environ.get("RUN_STATION", "Skatepark Radio")
KEY = os.environ.get("RUN_KEY", "skatepark")                              # idempotency-key prefix for song requests
TOKEN_FILE = os.environ.get("RUN_TOKEN_FILE") or os.environ.get("MAC_TOKEN_FILE", "")
