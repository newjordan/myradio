#!/usr/bin/env python3
"""Recorded step: the agent DJ names the station and asks for its first three songs (RUN_* settings in run_env.py)."""
import json
import os

from agent_dj import Agent
from run_env import STATION, SONGS, KEY

TAGLINE = os.environ.get("RUN_TAGLINE", "")
songs = json.loads(SONGS.read_text())
with Agent("04-agent-first-requests", "Your agent names the station and asks for the first songs") as dj:
    dj.tool("station_status", {})
    dj.tool("station_update", {"name": STATION, "tagline": TAGLINE})
    for song in songs[:3]:
        key = KEY + "-" + "".join(c if c.isalnum() else "-" for c in song["title"].lower())
        dj.tool("generation_enqueue", {"role": "song", "priority": 90, "idempotency_key": key[:120],
                                       "payload": {"title": song["title"], "tags": song["tags"], "lyrics": song["lyrics"],
                                                   "duration_s": 165, "steps": 8}},
                show=json.dumps({"role": "song", "priority": 90, "title": song["title"], "tags": song["tags"][:60] + "…",
                                 "lyrics": f'{len(song["lyrics"])} chars'}))
