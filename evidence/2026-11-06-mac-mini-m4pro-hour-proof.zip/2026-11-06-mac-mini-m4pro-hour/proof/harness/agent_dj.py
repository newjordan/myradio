#!/usr/bin/env python3
"""Act as the station's agent DJ through the real MCP adapter on the Mac mini (stdio over SSH), recording every tool call.

    from agent_dj import Agent
    with Agent("05-agent-dj", "Your agent takes the decks") as dj:
        dj.tool("station_status", {})
"""
import json
import subprocess
import sys
import time
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent))
from run_env import HOST, SHELL, REC, DATA, TRIAL, REMOTE_PORT
CASTS = REC / "terminal"
ADAPTER = f"cd {TRIAL} && exec .venv/bin/python -m myradio.mcp --data-dir {DATA} --port {REMOTE_PORT}"


class Agent:
    def __init__(self, cast_name, title):
        self.path = CASTS / (cast_name + ".cast")
        self.start = time.time()
        self.cast = self.path.open("w")
        self.cast.write(json.dumps({"version": 2, "width": 120, "height": 34, "timestamp": int(self.start), "title": title,
                                    "env": {"SHELL": SHELL, "TERM": "xterm-256color"}}) + "\n")
        self.say(f"\x1b[1;35m# {title}\x1b[0m")
        self.say(f"\x1b[2mMCP server: python -m myradio.mcp --data-dir {DATA} --port {REMOTE_PORT} (the config from Connect your agent)\x1b[0m")
        self.proc = subprocess.Popen(["ssh", "-o", "BatchMode=yes", HOST, ADAPTER], stdin=subprocess.PIPE, stdout=subprocess.PIPE,
                                     text=True, bufsize=1)
        self.next_id = 0
        info = self.call("initialize", {})
        self.say(f"\x1b[1;32mconnected\x1b[0m to {info.get('serverInfo', {}).get('name', 'myradio')}")

    def say(self, text):
        print(text.replace("\x1b[1;35m", "").replace("\x1b[1;32m", "").replace("\x1b[1;36m", "").replace("\x1b[2m", "").replace("\x1b[0m", ""), flush=True)
        self.cast.write(json.dumps([round(time.time() - self.start, 3), "o", text + "\r\n"]) + "\n")
        self.cast.flush()

    def call(self, method, params):
        self.next_id += 1
        self.proc.stdin.write(json.dumps({"jsonrpc": "2.0", "id": self.next_id, "method": method, "params": params}) + "\n")
        self.proc.stdin.flush()
        reply = json.loads(self.proc.stdout.readline())
        if "error" in reply:
            raise RuntimeError(reply["error"].get("message", "MCP error"))
        return reply["result"]

    def tool(self, name, arguments, show=None):
        shown = show if show is not None else json.dumps(arguments, ensure_ascii=False)
        self.say(f"\x1b[1;36magent ▸ {name}\x1b[0m {shown if len(shown) < 300 else shown[:300] + ' …'}")
        result = self.call("tools/call", {"name": name, "arguments": arguments})
        text = result["content"][0]["text"] if result.get("content") else "{}"
        try:
            value = json.loads(text)
        except ValueError:
            value = text
        brief = text if len(text) < 260 else text[:260] + " …"
        self.say(("\x1b[1;31mstation ◂ error: \x1b[0m" if result.get("isError") else "\x1b[2mstation ◂ \x1b[0m") + brief)
        if result.get("isError"):
            raise RuntimeError(text)
        return value

    def __enter__(self):
        return self

    def __exit__(self, *exc):
        self.proc.stdin.close()
        self.proc.wait(timeout=10)
        self.cast.close()


if __name__ == "__main__":
    with Agent(sys.argv[1], sys.argv[2]) as dj:
        print(json.dumps(dj.tool(sys.argv[3], json.loads(sys.argv[4]) if len(sys.argv) > 4 else {}), indent=2))
