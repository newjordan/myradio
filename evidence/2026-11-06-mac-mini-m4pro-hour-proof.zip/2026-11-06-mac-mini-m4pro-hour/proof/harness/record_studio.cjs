// Film a run's studio (RUN_REC, RUN_LOCAL_PORT, RUN_TOKEN_FILE; default the Mac mini) (through the SSH tunnel) for a while: node record_studio.cjs <name> <seconds> [hash]
const { chromium } = require(process.env.HOME + '/.nvm/versions/node/v24.16.0/lib/node_modules/playwright');
const fs = require('fs'), path = require('path');
const [name, seconds, hash] = process.argv.slice(2);
const out = path.join(process.env.RUN_REC || path.join(process.env.HOME, 'myradio-promo/recordings/2026-11-06-mac-mini'), 'studio');
fs.mkdirSync(out, { recursive: true });
const port = process.env.RUN_LOCAL_PORT || '8765';
const token = fs.readFileSync(process.env.RUN_TOKEN_FILE || process.env.MAC_TOKEN_FILE, 'utf8').trim();
(async () => {
  const browser = await chromium.launch({ args: ['--no-sandbox'] });
  const context = await browser.newContext({ viewport: { width: 1440, height: 900 }, recordVideo: { dir: out, size: { width: 1440, height: 900 } } });
  const page = await context.newPage();
  await page.goto(`http://127.0.0.1:${port}/#token=${token}`);
  await page.waitForFunction(() => document.getElementById('connection')?.textContent.includes('connected'), null, { timeout: 20000 });
  if (hash) await page.evaluate(h => { location.hash = h; }, hash);
  await page.waitForTimeout(Number(seconds) * 1000);
  await page.screenshot({ path: path.join(out, `${name}.png`) });
  const video = page.video(); await context.close(); await browser.close();
  fs.renameSync(await video.path(), path.join(out, `${name}.webm`));
  console.log('saved', path.join(out, `${name}.webm`));
})().catch(e => { console.error('recorder failed:', e.message); process.exit(1); });
