# The harness that ran the hour

These scripts drove the run from a separate Linux machine over SSH: `rec.py` records each setup step as an asciinema cast
with its real output and timing, `first_requests.py` and `agent_dj.py` act as the agent DJ through myradio's own MCP adapter
(`python3 -m myradio.mcp`, the command Connect your agent hands out), `hour_run.py` runs the hour (status check every 15 s,
DJ actions every minute, a 25 s clip of each new song from the station's own stream, studio films at the start, middle and
end), and `record_studio.cjs` films the studio with Playwright. `run_env.py` holds the per-machine settings.

These are the versions as of the end of both runs. The Mac mini hour (run first) used the same logic with two differences,
both added for the RTX 4080 run: the cap on how many fresh songs may wait to air (`RUN_LEAD`, which never came into play on
the Mac, where songs were made at about the speed they play), and the end-of-hour report reading each job's render timings.
For the Mac run those timings were collected the same way right after the hour and are in `report/renders.json`.
