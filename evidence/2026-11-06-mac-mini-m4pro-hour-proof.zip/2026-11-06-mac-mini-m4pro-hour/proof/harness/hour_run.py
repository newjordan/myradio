#!/usr/bin/env python3
"""Run a station for an hour on the machine in run_env.py (default: Skatepark Radio on the Mac mini) and keep the proof.

Phase 1: wait for the first generated song, queue it, press Start (the hour starts here).
Phase 2: for 60 minutes, every minute, act as the agent DJ through the real MCP adapter (keep 3+ carts queued, play fresh songs
first, request the next song before the pipeline runs dry, restart playout if it stopped), log the station every 15 s, record
25 s of the real stream audio of every new track, and film the studio at the start, middle and end.
Phase 3: write a proof report (what aired, render times, dead air, errors).
"""
import json
import os
import subprocess
import threading
import time
import urllib.request
from pathlib import Path

from agent_dj import Agent
from run_env import REC, TOKEN_FILE, SONGS as SONGS_FILE, LOCAL_PORT, STATION, KEY

HOME = Path.home()
(REC / "audio").mkdir(parents=True, exist_ok=True)
LOG = REC / "hour-run-log.jsonl"
TOKEN = Path(TOKEN_FILE).read_text().strip()
SONGS = json.loads(SONGS_FILE.read_text())
HOUR = int(os.environ.get("HOUR_SECONDS", "3600"))
BASE = f"http://127.0.0.1:{LOCAL_PORT}"
LEAD = int(os.environ.get("RUN_LEAD", "3"))   # ask for a new song only while fewer than this many fresh songs wait to air
NODE = str(HOME / ".nvm/versions/node/v24.16.0/bin/node")


def api(path):
    req = urllib.request.Request(BASE + path, headers={"X-Myradio-Token": TOKEN})
    with urllib.request.build_opener(urllib.request.ProxyHandler({})).open(req, timeout=15) as r:
        return json.loads(r.read())


def log(kind, **data):
    row = {"t": round(time.time(), 1), "kind": kind, **data}
    with LOG.open("a") as f:
        f.write(json.dumps(row, ensure_ascii=False) + "\n")
    print(time.strftime("%H:%M:%S"), kind, json.dumps(data, ensure_ascii=False)[:220], flush=True)


def snippet(index, title):
    """25 s of the station's real output, as heard by a listener of the local stream."""
    safe = "".join(c if c.isalnum() else "-" for c in title)[:40]
    out = REC / "audio" / f"{index:02d}-{safe}.wav"
    subprocess.run(["curl", "-s", "--max-time", "25", "-H", f"X-Myradio-Token: {TOKEN}", "-o", str(out), BASE + "/stream.wav"])
    log("audio_clip", file=out.name, bytes=out.stat().st_size if out.exists() else 0)


def film(name, seconds):
    env = {**os.environ}
    subprocess.Popen([NODE, str(HOME / "myradio-promo/record_studio.cjs"), name, str(seconds)], env=env,
                     stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
    log("film", name=name, seconds=seconds)


class DJ:
    def __init__(self):
        self.agent = None
        self.next_song = 3          # songs 1-3 were requested by the first-requests step

    def tool(self, name, args, show=None):
        for attempt in range(3):
            try:
                if self.agent is None:
                    self.agent = Agent("06-hour-agent-dj", f"Your agent DJs {STATION} for an hour")
                return self.agent.tool(name, args, show)
            except (OSError, ValueError, json.JSONDecodeError, BrokenPipeError) as exc:
                log("agent_reconnect", error=str(exc)[:120])
                self.agent = None
                time.sleep(3)
        raise RuntimeError("agent could not reach the station")

    def request_song(self):
        if self.next_song < len(SONGS):
            song, title = SONGS[self.next_song], SONGS[self.next_song]["title"]
        else:                                   # every lyric has been used: a new take (new seed) of an earlier song
            extra = self.next_song - len(SONGS)
            song = SONGS[extra % len(SONGS)]
            title = f'{song["title"]} (take {2 + extra // len(SONGS)})'
        self.next_song += 1
        key = KEY + "-" + "".join(c if c.isalnum() else "-" for c in title.lower())
        self.tool("generation_enqueue", {"role": "song", "priority": 70, "idempotency_key": key[:120],
                                         "payload": {"title": title, "tags": song["tags"], "lyrics": song["lyrics"], "duration_s": 165, "steps": 8}},
                  show=f'{{"role": "song", "title": "{title}", "tags": "{song["tags"][:50]}…"}}')
        log("dj_request", title=title)


def main():
    dj = DJ()
    log("start", phase="waiting for the first song")
    deadline = time.time() + 1800
    while time.time() < deadline:
        s = api("/api/status")
        if any(t["available"] for t in s["library"]):
            break
        time.sleep(15)
    else:
        log("abort", reason="no song after 30 minutes")
        return
    first = next(t for t in s["library"] if t["available"])
    dj.tool("queue_add", {"track_id": first["id"]})
    dj.tool("transport_start", {})
    hour_start = time.time()
    log("on_air", first=first["title"], hour_ends=time.strftime("%H:%M:%S", time.localtime(hour_start + HOUR)))
    film("06a-first-song-on-air", 40)

    played, last_current, clips, last_dj, filmed_mid = [], None, 0, 0, False
    seen_library = {first["id"]}
    while time.time() - hour_start < HOUR:
        try:
            s = api("/api/status")
        except OSError as exc:
            log("status_error", error=str(exc)[:120]); time.sleep(15); continue
        g = s["extensions"]["generation"]["status"]
        cur = s["current"]
        log("tick", running=s["running"], health=s["health"]["state"], current=cur["title"] if cur else None,
            elapsed=s["elapsed"], queue=[q["title"] for q in s["queue"]], library=len(s["library"]), jobs=g["jobs"],
            agent=s.get("agent_link", {}).get("last"))
        if cur and (last_current is None or cur["id"] != last_current):
            last_current = cur["id"]; clips += 1
            played.append({"title": cur["title"], "at": time.time(), "minute": round((time.time() - hour_start) / 60, 1)})
            log("now_playing", title=cur["title"], minute=played[-1]["minute"])
            threading.Thread(target=snippet, args=(clips, cur["title"]), daemon=True).start()
        if not filmed_mid and time.time() - hour_start > HOUR / 2:
            filmed_mid = True; film("06b-half-hour", 40)
        if time.time() - last_dj >= 60:
            last_dj = time.time()
            try:
                if not s["running"]:
                    dj.tool("transport_start", {}); log("dj_restart")
                ready = [t for t in s["library"] if t["available"] and t["kind"] == "music"]
                fresh = [t for t in ready if t["id"] not in seen_library]
                queued_ids = {q["track_id"] for q in s["queue"]}
                for t in fresh:                                       # a new song: play it next
                    seen_library.add(t["id"])
                    if t["id"] not in queued_ids:
                        dj.tool("queue_add", {"track_id": t["id"], "position": 0}); log("dj_premiere", title=t["title"])
                        queued_ids.add(t["id"])
                s2 = api("/api/status")
                recent = [p["title"] for p in played[-4:]]
                while len(s2["queue"]) < 3 and ready:
                    queued_titles = {q["title"] for q in s2["queue"]}
                    pool = [t for t in ready if t["title"] not in recent and t["title"] not in queued_titles] or ready
                    pool.sort(key=lambda t: max([p["at"] for p in played if p["title"] == t["title"]] or [0]))
                    pick = pool[0]
                    dj.tool("queue_add", {"track_id": pick["id"]}); log("dj_fill", title=pick["title"])
                    recent.append(pick["title"]); s2 = api("/api/status")
                aired = {p["title"] for p in played}
                waiting = [t for t in ready if t["title"] not in aired]
                if g["jobs"]["queued"] + g["jobs"]["running"] < 2 and len(waiting) < LEAD:
                    dj.request_song()
            except Exception as exc:
                log("dj_error", error=str(exc)[:200])
        time.sleep(15)

    film("06c-end-of-hour", 40)
    s = api("/api/status")
    g = s["extensions"]["generation"]["status"]
    renders = []
    try:
        jobs = []
        for state in ("succeeded", "failed"):
            jobs += api(f"/api/x/generation/jobs?state={state}").get("jobs", [])
        for job in jobs:
            detail = dj.tool("generation_job", {"job_id": job["id"]}, show=f'{{"job_id": "{job["id"][:8]}…"}}').get("job", {})
            timings = (detail.get("provenance") or {}).get("timings") or {}
            renders.append({"title": detail.get("title"), "state": detail.get("state"), "audio_s": timings.get("audio_s"),
                            "render_s": timings.get("worker_s"), "realtime_x": timings.get("realtime_x"), "error": detail.get("error")})
    except Exception as exc:
        log("render_report_error", error=str(exc)[:200])
    report = {"hour_start": time.strftime("%Y-%m-%d %H:%M:%S", time.localtime(hour_start)), "seconds": round(time.time() - hour_start),
              "played": played, "jobs": g["jobs"], "renders": renders, "library": [t["title"] for t in s["library"]],
              "running_at_end": s["running"], "health_at_end": s["health"]}
    (REC / "hour-run-report.json").write_text(json.dumps(report, indent=2, ensure_ascii=False))
    log("done", played=len(played), jobs=g["jobs"])
    if dj.agent:
        dj.agent.__exit__()


if __name__ == "__main__":
    main()
